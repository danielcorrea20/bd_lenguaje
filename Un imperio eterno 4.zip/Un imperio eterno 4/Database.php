<?php

class Database
{

    public static function conectar()
    {
        $driver = 'mysql';
        $host = '127.0.0.1';
        $port = '3306';
        $user = 'root';
        $password = '';
        $db = 'libro';

        $dsn = "$driver:dbname=$db;$host:host;$port:port";

        try {
            $gbd = new PDO($dsn, $user, $password);
        } catch (PDOException $e) {
            echo 'Ha debido ocurrir algun error' . $e->getMessage();
        }
        return $gbd;
    }


    public static function login($email, $password)
    {
        $sql = "SELECT * FROM 1_administradores WHERE email = '$email' && password = '$password'";
        $user = self::conectar()->query($sql);
        if ($user != null) {
            return $user->fetch(PDO::FETCH_ASSOC);
        } else {
            return null;
        }
    }

    public function getGotas($id)
    {
        $sql = "SELECT * FROM 1_gotas_de_escritura WHERE id = $id";
        $resultado = self::conectar()->query($sql);

        return $resultado;
    }
    public function getPersonajes($id)
    {
        $sql = "SELECT * FROM 1_personajes WHERE id = $id";
        $personaje = self::conectar()->query($sql);

        return $personaje;
    }

    public function getSintesis()
    {

        $sql = "SELECT * FROM 1_libro";
        $resultado = self::conectar()->query($sql);

        return $resultado;
    }

    public static function getAllPersonajes()
    {
        $sql = "SELECT * FROM 1_personajes";
        $resultado = self::conectar()->query($sql);



        return $resultado;
    }

    public static function getAllGotas()
    {
        $sql = "SELECT * FROM 1_gotas_de_escritura";
        $resultado = self::conectar()->query($sql);



        return $resultado;
    }

    public static function getAllComentarios()
    {
        $sql = "SELECT * FROM 1_comentario";
        $resultado = self::conectar()->query($sql);



        return $resultado;
    }

    public static function getAllClientes()
    {
        $sql = "SELECT * FROM 1_cliente";
        $resultado = self::conectar()->query($sql);

        return $resultado;
    }

    public static function deleteCLIENTE($id)
    {
        $sql = "DELETE FROM 1_cliente WHERE id = $id";
        self::conectar()->exec($sql);
    }

    public static function deleteCOMENTARIO($id)
    {
        $sql = "DELETE FROM 1_comentario WHERE id = $id";
        self::conectar()->exec($sql);
    }

    public static function deleteGOTAS($id)
    {
        $sql = "DELETE FROM 1_gotas_de_escritura WHERE id = $id";
        self::conectar()->exec($sql);
    }

    public static function deletePERSONAJES($id)
    {
        $sql = "DELETE FROM 1_personajes WHERE id = $id";

        self::conectar()->exec($sql);
    }

    public static function saveCLIENTE($datos)
    {
        $sql = "INSERT INTO 1_cliente (nombre, apellidos, email) VALUES ('$datos[0]', '$datos[1]', '$datos[2]')";
        self::conectar()->exec($sql);
    }

    public static function saveCOMENTARIO($datos)
    {
        $sql = "INSERT INTO 1_comentario (nombre, apellidos, email, fecha, comentario) VALUES ('$datos[0]', '$datos[1]', '$datos[2]', now(), '$datos[4]')";
        self::conectar()->exec($sql);
    }

    public static function saveGOTAS($datos)
    {
        $sql = "INSERT INTO 1_gotas_de_escritura (titulo, texto) VALUES ('$datos[0]', '$datos[1]')";
        self::conectar()->exec($sql);
    }

    public static function savePERSONAJES($datos)
    {
        $sql = "INSERT INTO 1_personajes (nombre, texto) VALUES ('$datos[0]', '$datos[1]')";
        self::conectar()->exec($sql);
    }

    public static function updateCLIENTE($datos)
    {
        $sql = "UPDATE 1_cliente SET nombre = '$datos[1]', apellidos = '$datos[2]', email = '$datos[3]', libro_id = $datos[4] WHERE id = $datos[0]";
        self::conectar()->exec($sql);
    }

    public static function updateCOMENTARIO($datos)
    {
        $sql = "UPDATE 1_comentario SET nombre = '$datos[1]', apellidos = '$datos[2]', email = '$datos[3]', fecha = NOW(), comentario = '$datos[5]' WHERE id = $datos[0]";
        self::conectar()->exec($sql);
    }

    public static function updateGOTAS($datos)
    {
        $sql = "UPDATE 1_gotas_de_escritura SET titulo = '$datos[1]', texto = '$datos[2]' WHERE id = $datos[0]";
        self::conectar()->exec($sql);
    }

    public static function updatePERSONAJES($datos)
    {
        $sql = "UPDATE 1_personajes SET nombre = '$datos[1]', texto = '$datos[2]' WHERE id = $datos[0]";
        self::conectar()->exec($sql);
    }

    public static function findById($id, $tabla)
    {
        $sql = "SELECT * FROM $tabla WHERE id = $id";
        $cliente = self::conectar()->query($sql);
        return $cliente->fetch(PDO::FETCH_ASSOC);
    }
}
